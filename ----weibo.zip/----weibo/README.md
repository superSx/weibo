# 模拟早期weibo
